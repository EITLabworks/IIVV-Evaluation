import numpy as np
from tqdm import tqdm
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import Lasso, LogisticRegression, RidgeClassifier
from sklearn.metrics import (
    confusion_matrix,
    f1_score,
    recall_score,
    roc_auc_score,
)
from sklearn.multiclass import OneVsRestClassifier
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.utils import shuffle as sk_shuffle
from toolbox import (
    Masking,
    find_all_indices,
    hot_coding,
)
from toolbox.loading import load_data
from toolbox.visualization import cmap_gradient, color_palette_full

import warnings
warnings.filterwarnings("ignore")

use_models = ["SVM", "RF", "Lasso"]
class_tasks = ["healthy_vs_cancer"]
snr_db = 30  # dB
random_state_repeats = 50
n_folds = 5


# load masking
IIVV = np.loadtxt("source/IIVV_patterns.txt", dtype=int)
mask = Masking(IIVV)
# set prints off
mask.prints = False

# data loading
(
    py_idx,
    patient_no,
    patient_sample,
    Zdata,
    Avg_Cutpats,
    LesionAssessment,
    labels_healthy_vs_cancer,
    labels_cancer_vs_hbd,
    labels_MC,
) = load_data(path="data", Cutpats_threshold=60, norm="freq")

import itertools


def iterate_over_loops(*loops):
    return itertools.product(*loops)


def generate_folds(Case, n_folds, random_state):
    unique_patients = np.unique(Case)
    np.random.seed(random_state)
    if len(Y.shape) == 1 or Y.shape[1] == 1:
        raise ValueError("Labels (Y) must be in one-hot encoding format")
    patient_indices = np.arange(len(unique_patients))
    np.random.shuffle(patient_indices)
    fold_size = len(patient_indices) // n_folds
    folds = []

    for i in range(n_folds):
        if i == n_folds - 1:
            test_indices = patient_indices[i * fold_size :]
        else:
            test_indices = patient_indices[i * fold_size : (i + 1) * fold_size]
        train_indices = np.setdiff1d(patient_indices, test_indices)
        folds.append((train_indices, test_indices))

    return folds


def add_noise_2d(signal, snr_db):
    signal_power = np.nanmean(signal**2)
    snr_linear = 10 ** (snr_db / 10)
    noise_power = signal_power / snr_linear
    noise = np.sqrt(noise_power) * np.random.normal(size=signal.shape)
    return signal + noise


def select_cat_data(X, Y, select: int):
    matches = np.all(Y == select, axis=1)
    idxs = np.where(matches)[0]

    return X[idxs, ...], idxs


def data_augmentation(X, Y, tar_num, snr_db, shuffle_data=True, random_state=42):
    if len(Y.shape) == 2:
        cats = np.unique(Y, axis=0)
    else:
        cats = np.unique(Y)
    X_aug = list()
    Y_aug = list()

    for selected_cat in cats:
        X_select, idxs = select_cat_data(X, Y, selected_cat)
        aug_num = tar_num - len(idxs)
        aug_idxs = np.random.randint(0, len(idxs), size=aug_num)

        for Xs in X_select:
            X_aug.append(Xs)
            Y_aug.append(selected_cat)

        for aug_idx in aug_idxs:
            Xs_noisy = add_noise_2d(X_select[aug_idx], snr_db)
            X_aug.append(Xs_noisy)
            Y_aug.append(selected_cat)
    X_aug = np.array(X_aug)
    Y_aug = np.array(Y_aug)
    if shuffle_data:
        X_aug, Y_aug = sk_shuffle(X_aug, Y_aug, random_state=random_state)

    return X_aug, Y_aug


def Model(
    architecture: str,
    X_train,
    Y_train,
    X_test,
    Y_test,
    random_state,
    inverse_mapping,
    fold,
    Msel,
    Fsel,
    class_task,
):
    """
    Train and evaluate a classifier based on the specified architecture.

    Parameters
    ----------
    architecture : str
        Specifies the classifier to use. Supported options are:
            # - "SVMscaler" : Supported Vector Machine with StandardScaler and OneVsRest strategy.
            - "SVM"       : Supported Vector Machine with OneVsRest strategy (no scaler).
            - "RF"        : Random Forest classifier with optional StandardScaler.
            # - "LR"        : Logistic Regression with StandardScaler and OneVsRest strategy.
            # - "RidgeRegr" : Ridge Classifier with StandardScaler and OneVsRest strategy.
            - "Lasso"     : Lasso-like classifier using Logistic Regression with L1 penalty.

    """
    if architecture == "SVMscaler":
        # print("\nNew Supported vector machine (SVM) with StandardScaler\n")
        m = make_pipeline(
            StandardScaler(),
            OneVsRestClassifier(
                SVC(kernel="linear", probability=True, random_state=random_state)
            ),
        )
    elif architecture == "SVM":
        # print("\nSupported vector machine (SVM)\n")
        m = OneVsRestClassifier(
            SVC(kernel="linear", probability=True, random_state=random_state)
        )

    elif architecture == "RF":
        # print("\nRandom Forest (RF)\n")
        m = make_pipeline(
            StandardScaler(),
            OneVsRestClassifier(
                RandomForestClassifier(max_depth=5, random_state=random_state)
            ),
        )

    elif architecture == "LR":
        # print("\nLogistic Regression (LR)\n")
        m = make_pipeline(
            StandardScaler(),
            OneVsRestClassifier(
                LogisticRegression(max_iter=1000, random_state=random_state)
            ),
        )

    # elif architecture == "RidgeRegr":
    #    print("\nRidge Classifier (RidgeRegr)\n")
    #    m = make_pipeline(
    #        StandardScaler(),
    #        OneVsRestClassifier(RidgeClassifier(random_state=random_state)),
    #    )

    elif architecture == "Lasso":
        # print("\nLasso Classifier (Lasso)\n")
        m = make_pipeline(
            StandardScaler(),
            OneVsRestClassifier(
                LogisticRegression(
                    penalty="l1",
                    solver="saga",
                    max_iter=2000,
                    random_state=random_state,
                )
            ),
        )

    else:
        raise ValueError(f"Unknown architecture: {architecture}")

    # Fit and predict
    y_score = m.fit(X_train, Y_train).predict_proba(X_test)
    Y_pred = m.predict(X_test)

    if Y_train.shape[1] == 2:
        y_test_tuples = [tuple(row) for row in Y_test.astype(int)]
        y_pred_tuples = [tuple(row) for row in Y_pred.astype(int)]
        # inverse mapping
        y_test_labels = [inverse_mapping[t] for t in y_test_tuples]
        y_pred_labels = [inverse_mapping[t] for t in y_pred_tuples]
        class_labels = list(inverse_mapping.values())
        # confusion matrix
        cm = confusion_matrix(y_test_labels, y_pred_labels, labels=class_labels)
        TP = cm[0, 0]  # true positives (TP)
        TN = cm[1, 1]  # true negatives (TN)
        FN = cm[0, 1]  # false negatives (FN)
        FP = cm[1, 0]  # false positives (FP)
        class_labels = list(inverse_mapping.values())

        precision = TP/(TP+FP)
        sensitivity = TP / (TP + FN)
        specificity = TN / (TN + FP)
    
    score = roc_auc_score(Y_test, y_score)
    #acc_score = accuracy_score(Y_test, Y_pred)
    recall = recall_score(Y_test, Y_pred, labels=None, average="weighted")
    f1 = f1_score(Y_test, Y_pred, average="weighted")

    if Y_train.shape[1] != 2:
        precision = None
        sensitivity = None
        specificity = None
        
    performance = {
        "Architecture": architecture,
        "Fold": fold,
        "Random_state": random_state,
        "ROC AUC": score,
        "Precision": precision,
        "Sensitivity": sensitivity,
        "Specificity": specificity,
        "Recall": recall,
        "F1-score": f1,
        "Mask": Msel,
        "Freq. selection": Fsel,
        "Task": class_task,
    }
    return performance


# load frequency selection
tmp = np.load("results/freq_fold_results.npz", allow_pickle=True)
top_freqs_baseline = tmp["top_freqs_baseline"]

Freq_sel = {
    "Top 2": top_freqs_baseline[:2],
    "Top 3": top_freqs_baseline[:3],
    "Top 5": top_freqs_baseline[:5],
    "Top 12": top_freqs_baseline[:12],
    "All": top_freqs_baseline,  # np.arange(31), # it doesn't matter
}

# load masking selection
Mask_sel = {
    "Long a+": "vv_long_across",
    "Long a+ ext.": "vv_long_across_extended",
    "Med. a+ ext.": "vv_medium_across_extended",
    "Close skip 1": "vv_distance_close_skip_1",
    "All": "all",
}

for class_task, Fsel, Msel in iterate_over_loops(
    class_tasks, Freq_sel.keys(), Mask_sel.keys()
):
    print(class_task, Fsel, Msel)

    if class_task == "healthy_vs_cancer":
        select_idx = find_all_indices(
            labels_healthy_vs_cancer, ["Healthy", "Cancer"], split=False
        )
        labels = labels_healthy_vs_cancer[select_idx]
        target_num_augmentation = 150

    elif class_task == "cancer_vs_hbd":
        select_idx = find_all_indices(
            labels_cancer_vs_hbd, ["Non-cancer", "Cancer"], split=False
        )
        labels = labels_cancer_vs_hbd[select_idx]
        target_num_augmentation = 150

    elif class_task == "MC":
        select_idx = find_all_indices(
            labels_MC,
            ["Healthy", "Cancer", "Mild dysplasia", "Severe dysplasia", "Benign"],
            split=False,
        )
        labels = labels_MC[select_idx]
        target_num_augmentation = 100

    Case = patient_no[select_idx]
    X = Zdata[select_idx, ...]
    Y, inverse_mapping = hot_coding(labels)
    # set mask
    mask.IIVV_mask(Mask_sel[Msel], plot=False)

    # ...................................
    # start repeats random states x folds
    stats_df = []
    for random_state in tqdm(range(random_state_repeats)):
        folds = generate_folds(Case, n_folds, random_state)
        for fold_idx, (train_patients_idx, test_patients_idx) in enumerate(folds):
            fold = fold_idx + 1

            unique_patients = np.unique(Case)
            train_patients = unique_patients[train_patients_idx]
            test_patients = unique_patients[test_patients_idx]
            train_mask = np.isin(Case, train_patients)
            test_mask = np.isin(Case, test_patients)
            train_pct = train_mask.mean() * 100
            test_pct = test_mask.mean() * 100

            train_samples = np.sum(train_mask)
            test_samples = np.sum(test_mask)
            train_patient_count = len(train_patients)
            test_patient_count = len(test_patients)

            X_train, Y_train = data_augmentation(
                X[train_mask],
                Y[train_mask],
                target_num_augmentation,
                snr_db,
                shuffle_data=True,
                random_state=random_state,
            )

            X_test = X[test_mask]
            Y_test = Y[test_mask]

            X_train = X_train[:, Freq_sel[Fsel], :]
            X_test = X_test[:, Freq_sel[Fsel], :]
            X_train = X_train[:, :, mask.mask]
            X_test = X_test[:, :, mask.mask]
            X_train = X_train.reshape(X_train.shape[0], -1)
            X_test = X_test.reshape(X_test.shape[0], -1)

            # ------ Models ------
            for use_model in use_models:
                try:
                    pf = Model(
                        use_model,
                        X_train,
                        Y_train,
                        X_test,
                        Y_test,
                        random_state,
                        inverse_mapping,
                        fold,
                        Msel,
                        Fsel,
                        class_task,
                    )
                    stats_df.append(pf)
                except:
                    print(
                        "random state:",
                        random_state,
                        "for",
                        use_model,
                        "isn't working.",
                    )
            # -----------------

    df = pd.DataFrame(stats_df)
    df.to_csv(f"results/LPOCV_{class_task}_{Fsel}_{Msel}.csv", index=False)
